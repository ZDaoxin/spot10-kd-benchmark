from __future__ import print_function, division

import sys
import time
import torch
import torch.nn.functional as F

from .util import AverageMeter, accuracy


def train_distill(epoch, train_loader, module_list, criterion_list, optimizer, opt):
    """One epoch distillation"""

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    for module in module_list:
        module.train()
    module_list[-1].eval()

    criterion_cls = criterion_list[0]
    criterion_div = criterion_list[1]
    criterion_kd = criterion_list[2] if len(criterion_list) > 2 else None

    model_s = module_list[0]
    model_t = module_list[-1]

    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()

    end = time.time()
    for idx, data in enumerate(train_loader):
        input, target = data
        data_time.update(time.time() - end)

        input = input.to(device).float()
        target = target.to(device)

        preact = opt.distill in ['itrd']
        feat_s, logit_s = model_s(input, is_feat=True, preact=preact)

        with torch.no_grad():
            feat_t, logit_t = model_t(input, is_feat=True, preact=preact)
            feat_t = [f.detach() for f in feat_t]

        loss_cls = criterion_cls(logit_s, target)
        loss_div = criterion_div(logit_s, logit_t)

        if opt.distill == 'kd':
            loss_kd = 0
        elif opt.distill == 'ttm':
            loss_kd = criterion_kd(logit_s, logit_t)
        elif opt.distill == 'wttm':
            loss_kd = criterion_kd(logit_s, logit_t)
        elif opt.distill == 'itrd':
            f_s = feat_s[-1].to(device)
            f_t = feat_t[-1].to(device)
            loss_kd = (
                opt.lambda_corr * criterion_kd.forward_correlation_it(f_s, f_t) +
                opt.lambda_mutual * criterion_kd.forward_mutual_it(f_s, f_t)
            )
        elif opt.distill == 'dist':
            logit_s = logit_s.to(device)
            logit_t = logit_t.to(device)
            loss_kd = criterion_kd(logit_s, logit_t)
        else:
            raise NotImplementedError(opt.distill)

        loss = opt.gamma * loss_cls + opt.alpha * loss_div + opt.beta * loss_kd

        acc1 = accuracy(logit_s, target, topk=(1,))
        losses.update(loss.item(), input.size(0))
        top1.update(acc1[0], input.size(0))

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        batch_time.update(time.time() - end)
        end = time.time()

        if idx % opt.print_freq == 0:
            print(f'Epoch: [{epoch}][{idx}/{len(train_loader)}]\t'
                  f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  f'Loss {losses.val:.4f} ({losses.avg:.4f})\t'
                  f'Acc@1 {top1.val.item():.3f} ({top1.avg.item():.3f})')
            sys.stdout.flush()

    print(f' * Acc@1 {top1.avg.item():.3f}, Train Loss {losses.avg:.4f}')
    return top1.avg, losses.avg


def validate(val_loader, model, criterion, opt, dataset_type="Validation"):
    """Validation"""
    batch_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()

    label_names = [
        "Cheetah", "Deer", "Giraffe", "Hyena", "Jaguar",
        "Leopard", "Tapir Calf", "Tiger", "Whale Shark", "Zebra"
    ]
    num_classes = len(label_names)
    correct_per_class = [0 for _ in range(num_classes)]
    total_per_class = [0 for _ in range(num_classes)]

    model.eval()
    with torch.no_grad():
        end = time.time()
        for idx, (input, target) in enumerate(val_loader):
            input = input.float().cuda() if torch.cuda.is_available() else input.float()
            target = target.cuda() if torch.cuda.is_available() else target

            output = model(input)
            loss = criterion(output, target)

            acc1 = accuracy(output, target, topk=(1,))
            losses.update(loss.item(), input.size(0))
            top1.update(acc1[0], input.size(0))

            pred = output.argmax(dim=1)
            for i in range(len(target)):
                label = target[i].item()
                correct_per_class[label] += (pred[i] == target[i]).item()
                total_per_class[label] += 1

    print(f'{dataset_type} Complete | Acc@1: {top1.avg.item():.3f}% | Loss: {losses.avg:.4f}')

    print(f'\n Per-Class Accuracy on {dataset_type}:')
    for i in range(num_classes):
        name = label_names[i]
        if total_per_class[i] == 0:
            acc = 0.0
        else:
            acc = 100 * correct_per_class[i] / total_per_class[i]
        print(f"  {name:12s}: {acc:.2f}%")

    return top1.avg, losses.avg
