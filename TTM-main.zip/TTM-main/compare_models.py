import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision.utils import save_image
import argparse
from models import model_dict
from dataset.SPOTS_10 import SPOTS10Instance
from torchvision import transforms
from collections import defaultdict

label_names = [
    "Cheetah", "Deer", "Giraffe", "Hyena", "Jaguar",
    "Leopard", "Tapir Calf", "Tiger", "Whale Shark", "Zebra"
]

def load_model(pth_path, device):
    model = model_dict['ResNet50'](num_classes=10)
    model.to(device)
    state = torch.load(pth_path, map_location=device)
    state_dict = state['model'] if 'model' in state else state

    new_state_dict = {}
    for k, v in state_dict.items():
        if k.startswith("module.student."):
            k = k.replace("module.student.", "")
        elif k.startswith("module.teacher."):
            continue
        elif k.startswith("module."):
            k = k.replace("module.", "")
        new_state_dict[k] = v

    model.load_state_dict(new_state_dict, strict=True)
    model.eval()
    return model

def main(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    save_dir = f"{args.model1_name}_vs_{args.model2_name}"
    os.makedirs(save_dir, exist_ok=True)

    # Disagreement image subfolders
    kd_right = os.path.join(save_dir, f"{args.model1_name}_correct_{args.model2_name}_wrong")
    ttm_right = os.path.join(save_dir, f"{args.model2_name}_correct_{args.model1_name}_wrong")
    os.makedirs(kd_right, exist_ok=True)
    os.makedirs(ttm_right, exist_ok=True)

    transform = transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.Grayscale(num_output_channels=3),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    test_dataset = SPOTS10Instance(args.data_dir, kind="test", transform=transform)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)

    model1 = load_model(args.model1_path, device)
    model2 = load_model(args.model2_path, device)

    class_correct_1 = defaultdict(int)
    class_correct_2 = defaultdict(int)
    class_total = defaultdict(int)

    disagreement_total = 0
    kd_better = 0
    ttm_better = 0
    total_correct_1 = 0
    total_correct_2 = 0
    total_samples = 0

    with torch.no_grad():
        for idx, (img, label) in enumerate(test_loader):
            img, label = img.to(device), label.to(device)
            out1 = model1(img)
            out2 = model2(img)

            pred1 = out1.argmax(dim=1).item()
            pred2 = out2.argmax(dim=1).item()
            true = label.item()

            class_total[true] += 1
            total_samples += 1

            if pred1 == true:
                class_correct_1[true] += 1
                total_correct_1 += 1
            if pred2 == true:
                class_correct_2[true] += 1
                total_correct_2 += 1

            if pred1 != pred2:
                disagreement_total += 1
                filename = f"{idx:04d}_GT-{label_names[true]}_{args.model1_name}-{label_names[pred1]}_{args.model2_name}-{label_names[pred2]}.png"
                if pred1 == true and pred2 != true:
                    kd_better += 1
                    save_image(img.cpu(), os.path.join(kd_right, filename))
                elif pred2 == true and pred1 != true:
                    ttm_better += 1
                    save_image(img.cpu(), os.path.join(ttm_right, filename))

    print(f"\n[Model Comparison: {args.model1_name} VS {args.model2_name}]")

    print(f"\nPer-class Accuracy of [{args.model1_name}]:")
    for i in range(10):
        acc = 100. * class_correct_1[i] / class_total[i] if class_total[i] > 0 else 0
        print(f"{label_names[i]:<15}: {acc:.2f}% ({class_correct_1[i]}/{class_total[i]})")

    print(f"Overall Accuracy of [{args.model1_name}]: {100. * total_correct_1 / total_samples:.2f}% ({total_correct_1}/{total_samples})")

    print(f"\nPer-class Accuracy of [{args.model2_name}]:")
    for i in range(10):
        acc = 100. * class_correct_2[i] / class_total[i] if class_total[i] > 0 else 0
        print(f"{label_names[i]:<15}: {acc:.2f}% ({class_correct_2[i]}/{class_total[i]})")

    print(f"Overall Accuracy of [{args.model2_name}]: {100. * total_correct_2 / total_samples:.2f}% ({total_correct_2}/{total_samples})")

    print(f"\nTotal disagreements: {disagreement_total}")
    print(f"{args.model1_name} correct but {args.model2_name} wrong: {kd_better}")
    print(f"{args.model2_name} correct but {args.model1_name} wrong: {ttm_better}")
    print(f"Disagreement images saved in: {save_dir}/")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Compare Two Models on SPOTS-10")
    parser.add_argument('--model1_name', type=str, required=True)
    parser.add_argument('--model1_path', type=str, required=True)
    parser.add_argument('--model2_name', type=str, required=True)
    parser.add_argument('--model2_path', type=str, required=True)
    parser.add_argument('--data_dir', type=str, default="D:/cognitive_science/mlp/TTM-main/data/spots-10")

    args = parser.parse_args()
    main(args)
