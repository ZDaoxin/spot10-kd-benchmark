import os
import torch
import argparse
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, accuracy_score
from torch.utils.data import DataLoader
from torchvision import transforms
from models import model_dict
from dataset.SPOTS_10 import SPOTS10Instance

label_names = [
    "Cheetah", "Deer", "Giraffe", "Hyena", "Jaguar",
    "Leopard", "Tapir Calf", "Tiger", "Whale Shark", "Zebra"
]

def load_model(model_path, device):
    model = model_dict['ResNet50'](num_classes=10).to(device)
    state = torch.load(model_path, map_location=device)
    state_dict = state['model'] if 'model' in state else state

    new_state = {}
    for k, v in state_dict.items():
        if k.startswith("teacher.") or k.startswith("module.teacher."):
            continue
        if k.startswith("module.student."):
            k = k.replace("module.student.", "")
        elif k.startswith("module."):
            k = k.replace("module.", "")
        new_state[k] = v

    model.load_state_dict(new_state, strict=True)
    model.eval()
    return model

def plot_confusion(model_path, model_name, data_dir, save_dir):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    transform = transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.Grayscale(num_output_channels=3),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    dataset = SPOTS10Instance(data_dir, kind="test", transform=transform)
    loader = DataLoader(dataset, batch_size=64, shuffle=False)

    model = load_model(model_path, device)

    all_preds = []
    all_labels = []

    with torch.no_grad():
        for x, y in loader:
            x = x.to(device)
            logits = model(x)
            preds = torch.argmax(logits, dim=1).cpu().tolist()
            labels = y.tolist()
            all_preds.extend(preds)
            all_labels.extend(labels)

    acc = accuracy_score(all_labels, all_preds) * 100
    print(f"\nOverall Accuracy of [{model_name}]: {acc:.2f}%")

    cm = confusion_matrix(all_labels, all_preds)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=label_names)

    fig, ax = plt.subplots(figsize=(10, 10))
    disp.plot(ax=ax, cmap="Blues", xticks_rotation=45)
    plt.title(f"Confusion Matrix: {model_name}")
    plt.tight_layout()

    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, f"{model_name}_confusion_matrix.png")
    plt.savefig(save_path)
    print(f"Confusion matrix saved to: {save_path}")
    plt.show()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_path', type=str, required=True, help='Path to .pth file')
    parser.add_argument('--model_name', type=str, required=True, help='Name of the model (for title & filename)')
    parser.add_argument('--data_dir', type=str, default='D:/cognitive_science/mlp/TTM-main/data/spots-10', help='SPOTS-10 dataset path')
    parser.add_argument('--save_dir', type=str, default='./confusion_matrices', help='Directory to save confusion matrix plot')
    args = parser.parse_args()

    plot_confusion(args.model_path, args.model_name, args.data_dir, args.save_dir)
