import os
import numpy as np
from torch.utils.data import Dataset, DataLoader, random_split
from torchvision import transforms
from PIL import Image


def get_data_folder():
    data_folder = './data/spots-10/'
    if not os.path.isdir(data_folder):
        raise FileNotFoundError(f"Dataset path {data_folder} does not exist.")
    return data_folder


class SPOTS10Instance(Dataset):
    def __init__(self, dataset_dir, kind="train", transform=None):
        self.data_folder = dataset_dir
        self.images, self.labels = self._load_data(kind)
        self.transform = transform

    def _load_data(self, kind):
        labels_path = os.path.join(self.data_folder, f'{kind}-labels-idx1-ubyte.gz')
        images_path = os.path.join(self.data_folder, f'{kind}-images-idx3-ubyte.gz')

        import gzip
        import struct
        from array import array

        with gzip.open(labels_path, 'rb') as file:
            magic, size = struct.unpack(">II", file.read(8))
            labels = array("B", file.read())

        with gzip.open(images_path, 'rb') as file:
            magic, size, rows, cols = struct.unpack(">IIII", file.read(16))
            image_data = array("B", file.read())

        images = np.array(image_data, dtype=np.uint8).reshape(size, rows, cols)

        return images, np.array(labels)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        image = self.images[idx]
        label = self.labels[idx]

        if self.transform:
            image = Image.fromarray(image).convert('L')
            image = self.transform(image)

        return image, label


def get_spots10_dataloaders(batch_size=128, num_workers=8, val_split=0.2):
    dataset_dir = get_data_folder()

    train_transform = transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.Grayscale(num_output_channels=3),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    test_transform = transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.Grayscale(num_output_channels=3),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    full_train_dataset = SPOTS10Instance(dataset_dir, kind="train", transform=None)
    test_dataset = SPOTS10Instance(dataset_dir, kind="test", transform=test_transform)

    train_size = int((1 - val_split) * len(full_train_dataset))
    val_size = len(full_train_dataset) - train_size
    train_dataset, val_dataset = random_split(full_train_dataset, [train_size, val_size])

    train_dataset.dataset.transform = train_transform
    val_dataset.dataset.transform = test_transform

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

    return train_loader, val_loader, test_loader


if __name__ == "__main__":
    train_loader, val_loader, test_loader = get_spots10_dataloaders(batch_size=128, num_workers=4)

    print("Train set size:", len(train_loader.dataset))
    print("Validation set size:", len(val_loader.dataset))
    print("Test set size:", len(test_loader.dataset))

    images, labels = next(iter(train_loader))
    print("Sample image shape:", images.shape)
    print("Sample labels:", labels[:10])
