from .ttm import TTM
from .wttm import WTTM
from .kd import DistillKL
from .crd import CRDLoss
from .itrd import ITLoss
from .dist import DIST