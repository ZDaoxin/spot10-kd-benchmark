from __future__ import print_function
import os
import argparse
import time
import numpy as np
import random
import torch
import torch.optim as optim
import torch.nn as nn
import torch.backends.cudnn as cudnn
import warnings
import matplotlib.pyplot as plt
import pandas as pd
warnings.simplefilter("ignore", category=FutureWarning)
from torchvision.models import resnet50

from models import model_dict
from dataset.SPOTS_10 import get_spots10_dataloaders
from helper.util import adjust_learning_rate
from distiller_zoo import TTM, WTTM, DistillKL, ITLoss, DIST
from helper.loops import train_distill, validate


def parse_option():
    parser = argparse.ArgumentParser('SPOTS-10 Student Model Training')

    parser.add_argument('--print_freq', type=int, default=250, help='Print frequency')
    parser.add_argument('--batch_size', type=int, default=64, help='Batch size')
    parser.add_argument('--num_workers', type=int, default=8, help='Number of workers')
    parser.add_argument('--epochs', type=int, default=5, help='Number of training epochs')

    parser.add_argument('--learning_rate', type=float, default=0.05, help='Learning rate')
    parser.add_argument('--lr_decay_epochs', type=str, default='60,75,90', help='LR decay schedule')
    parser.add_argument('--lr_decay_rate', type=float, default=0.1, help='LR decay rate')
    parser.add_argument('--weight_decay', type=float, default=0.0005, help='Weight decay')
    parser.add_argument('--momentum', type=float, default=0.9, help='Momentum')

    parser.add_argument('--dataset_dir', type=str, default='./data/spots-10', help='SPOTS-10 dataset path')
    parser.add_argument('--path_t', type=str, required=True, help='Path to teacher model')

    parser.add_argument('--model_s', type=str, required=True,
                        choices=['resnet8', 'resnet14', 'resnet20', 'resnet32', 'resnet44', 'resnet56', 'resnet110',
                                 'resnet8x4', 'resnet32x4', 'wrn_16_1', 'wrn_16_2', 'wrn_40_1', 'wrn_40_2',
                                 'vgg8', 'vgg11', 'vgg13', 'vgg16', 'vgg19', 'ResNet50',
                                 'MobileNetV2', 'ShuffleV1', 'ShuffleV2'],
                        help='Student model')

    parser.add_argument('--distill', type=str, default='kd', choices=['kd', 'ttm', 'wttm', 'itrd', 'dist'])
    parser.add_argument('--ttm_l', type=float, default=1, help='TTM distillation exponent')
    parser.add_argument('--kd_T', type=float, default=4.0, help='Temperature for KD distillation')

    parser.add_argument('-r', '--gamma', type=float, default=0.1, help='weight for classification')
    parser.add_argument('-a', '--alpha', type=float, default=0.5, help='weight balance for additional loss')
    parser.add_argument('-b', '--beta', type=float, default=0.5, help='weight balance for main loss')

    parser.add_argument('--lambda_corr', type=float, default=2.0, help='correlation loss weight')
    parser.add_argument('--lambda_mutual', type=float, default=1.0, help='mutual information loss weight')
    parser.add_argument('--alpha_it', type=float, default=1.50, help="Renyis alpha for IT loss")

    parser.add_argument('--dist_beta', type=float, default=0.5, help="weight for inter loss")
    parser.add_argument('--dist_gamma', type=float, default=0.5, help="weight for intra loss")
    parser.add_argument('--dist_tau', type=float, default=3, help="temperature for DIST")

    opt = parser.parse_args()

    opt.model_path = './scripts/save/spots10_student_model'
    opt.log_pth = './scripts/save/spots10_student_log'

    os.makedirs(opt.model_path, exist_ok=True)
    os.makedirs(opt.log_pth, exist_ok=True)

    opt.lr_decay_epochs = list(map(int, opt.lr_decay_epochs.split(',')))

    return opt

def save_training_results(log_dir, model_name, distill_method, results):
    os.makedirs(log_dir, exist_ok=True)
    filename = f"{model_name}_{distill_method}_training_log.csv"
    filepath = os.path.join(log_dir, filename)

    df = pd.DataFrame(results)
    df.to_csv(filepath, index=False)
    print(f"Training log saved to {filepath}")


def plot_results(log_dir, model_name, distill_method, results):
    os.makedirs(log_dir, exist_ok=True)
    filename = f"{model_name}_{distill_method}_training_plot.png"
    filepath = os.path.join(log_dir, filename)

    epochs = range(1, len(results["train_acc"]) + 1)

    plt.figure(figsize=(12, 6))

    plt.subplot(1, 2, 1)
    plt.plot(epochs, results["train_acc"], label="Train Accuracy")
    plt.plot(epochs, results["val_acc"], label="Validation Accuracy")
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy (%)")
    plt.legend()
    plt.title("Training & Validation Accuracy")

    plt.subplot(1, 2, 2)
    plt.plot(epochs, results["train_loss"], label="Train Loss")
    plt.plot(epochs, results["val_loss"], label="Validation Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.legend()
    plt.title("Training & Validation Loss")

    plt.tight_layout()
    plt.savefig(filepath)
    plt.close()
    print(f"Training plot saved to {filepath}")


def main():
    opt = parse_option()
    best_acc = 0
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_loader, val_loader, test_loader = get_spots10_dataloaders(
        batch_size=opt.batch_size, num_workers=opt.num_workers
    )

    num_classes = 10
    opt.n_data = len(train_loader.dataset)

    model_t = model_dict['ResNet50'](num_classes=100)
    checkpoint = torch.load(opt.path_t, map_location=device)

    model_t.linear = nn.Linear(model_t.linear.in_features, num_classes)
    torch.nn.init.kaiming_normal_(model_t.linear.weight, mode='fan_in', nonlinearity='relu')
    model_t.linear.bias.data.zero_()

    if 'model' in checkpoint:
        state_dict = checkpoint['model']
    else:
        state_dict = checkpoint

    filtered_state_dict = {k: v for k, v in state_dict.items() if "linear" not in k}
    model_t.to(device)

    model_s = model_dict[opt.model_s](num_classes=num_classes).to(device)

    dummy_input = torch.randn(2, 3, 32, 32).to(device)
    feat_s, _ = model_s(dummy_input, is_feat=True)
    feat_t, _ = model_t(dummy_input, is_feat=True)

    opt.s_dim = feat_s[-1].shape[1]
    opt.t_dim = feat_t[-1].shape[1]

    criterion_cls = nn.CrossEntropyLoss()
    criterion_div = DistillKL(opt.kd_T)

    if opt.distill == 'kd':
        criterion_kd = DistillKL(opt.kd_T)
    elif opt.distill == 'ttm':
        criterion_kd = TTM(opt.ttm_l)
    elif opt.distill == 'wttm':
        criterion_kd = WTTM(opt.ttm_l)
    elif opt.distill == 'itrd':
        criterion_kd = ITLoss(opt)
    elif opt.distill == 'dist':
        criterion_kd = DIST(opt.dist_beta, opt.dist_gamma, opt.dist_tau)
    else:
        raise NotImplementedError(f"Unsupported distillation method: {opt.distill}")

    criterion_list = nn.ModuleList([criterion_cls, criterion_div, criterion_kd])

    optimizer = optim.SGD(
        model_s.parameters(),
        lr=opt.learning_rate,
        momentum=opt.momentum,
        weight_decay=opt.weight_decay
    )

    results = {"epoch": [], "train_acc": [], "train_loss": [], "val_acc": [], "val_loss": []}

    for epoch in range(1, opt.epochs + 1):
        adjust_learning_rate(epoch, opt, optimizer)
        print(f"\nEpoch {epoch}/{opt.epochs}: Training Student Model ({opt.model_s})...")

        train_acc, train_loss = train_distill(epoch, train_loader, [model_s, model_t], criterion_list, optimizer, opt)
        val_acc, val_loss = validate(val_loader, model_s, criterion_cls, opt, "Validation")

        results["epoch"].append(epoch)
        results["train_acc"].append(train_acc.item())
        results["train_loss"].append(train_loss)
        results["val_acc"].append(val_acc.item())
        results["val_loss"].append(val_loss)

        if val_acc > best_acc:
            best_acc = val_acc
            save_path = os.path.join(opt.model_path, f"{opt.model_s}_best.pth")
            torch.save({'epoch': epoch, 'model': model_s.state_dict(), 'best_acc': best_acc}, save_path)
            print(f"Saved best model to: {save_path}")

    print(f"Best Validation Accuracy: {best_acc.item():.2f}%")

    save_training_results(opt.log_pth, opt.model_s, opt.distill, results)
    plot_results(opt.log_pth, opt.model_s, opt.distill, results)

    test_acc, test_loss = validate(test_loader, model_s, criterion_cls, opt, "Test")
    print(f"Test Accuracy: {test_acc.item():.2f}% | Loss: {test_loss:.4f}")

if __name__ == '__main__':
    main()
