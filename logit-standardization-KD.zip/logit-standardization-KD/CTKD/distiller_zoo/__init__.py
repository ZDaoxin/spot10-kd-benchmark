from .DKD import DKDloss
from .KD import DistillKL, DistillKL_logit_stand
from .PKT import PKT
from .SP import Similarity
from .VID import VIDLoss
