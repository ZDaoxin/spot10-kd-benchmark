import os
# from .resnet import (
#     resnet8,
#     resnet14,
#     resnet20,
#     resnet32,
#     resnet44,
#     resnet56,
#     resnet110,
#     resnet8x4,
#     resnet32x4,
# )
from .resnetv2 import ResNet50, ResNet101

spots10_model_prefix = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), 
    "../../../download_ckpts/cifar_teachers/"
)
spots10_model_dict = {
    # teachers
    "ResNet50": (
        ResNet50,
        spots10_model_prefix + "ResNet50_vanilla/ckpt_epoch_240.pth",
    ),
    "ResNet101": (
        ResNet101,
        spots10_model_prefix + "ResNet101_vanilla/ckpt_epoch_240.pth",
    )
}
