from .cifar import cifar_model_dict
from .imagenet import imagenet_model_dict
from .spots10 import spots10_model_dict
