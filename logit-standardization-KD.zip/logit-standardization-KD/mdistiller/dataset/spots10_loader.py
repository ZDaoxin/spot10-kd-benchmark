import os
import struct
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image
import gzip
from torch.utils.data import random_split

# 解析 ubyte 格式文件
def load_ubyte_images(file_path):
    if file_path.endswith('.gz'):
        with gzip.open(file_path, 'rb') as f:
            _, num, rows, cols = struct.unpack('>IIII', f.read(16))  # read document head
            data = np.frombuffer(f.read(), dtype=np.uint8).reshape(num, rows, cols)  # shape to (N, 32, 32) 
    else:
        with open(file_path, 'rb') as f:
            _, num, rows, cols = struct.unpack('>IIII', f.read(16))  
            data = np.frombuffer(f.read(), dtype=np.uint8).reshape(num, rows, cols)  
    return data

def load_ubyte_labels(file_path):
    if file_path.endswith('.gz'):
        with gzip.open(file_path, 'rb') as f:
            _, num = struct.unpack('>II', f.read(8))  
            labels = np.frombuffer(f.read(), dtype=np.uint8) 
    else:
        with open(file_path, 'rb') as f:
            _, num = struct.unpack('>II', f.read(8))  
            labels = np.frombuffer(f.read(), dtype=np.uint8)  
    return labels


# SPOTS10Dataset
class SPOTS10Dataset(Dataset):
    def __init__(self, image_path, label_path, transform=None):
        self.images = load_ubyte_images(image_path)  # origin (N, 32, 32)
        self.labels = load_ubyte_labels(label_path)
        self.transform = transform

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        img = self.images[idx]  # get single pic (32, 32, 3)
        label = self.labels[idx]

        # Convert NumPy array to PIL image
        img = Image.fromarray(img, mode='L')  # 'L' Representation grayscale image

        if self.transform is not None:
            img = self.transform(img)  # transform

        return img, torch.tensor(label, dtype=torch.long), idx


# get DataLoader
def get_spots10_dataloaders(batch_size=64, num_workers=4):
    # Gets the absolute path to the current file
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # Calculate the absolute path of data/spots10
    data_folder = os.path.abspath(os.path.join(current_dir, "../../data/spots10"))

    # check if path exist
    if not os.path.exists(data_folder):
        raise FileNotFoundError(f"path not exist: {data_folder}")

    # 训练数据 transform
    train_transform = transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    # 测试数据 transform
    test_transform = transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    # 加载原始训练集
    train_dataset = SPOTS10Dataset(
        image_path=os.path.join(data_folder, "train-images-idx3-ubyte.gz"),  
        label_path=os.path.join(data_folder, "train-labels-idx1-ubyte.gz"),  
        transform=None
    )

    # train 80% and val 20%
    train_size = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size
    train_subset, val_subset = random_split(train_dataset, [train_size, val_size])

    train_subset.dataset.transform = train_transform
    val_subset.dataset.transform = test_transform  # val Normalize only, no enhancement

    # load test set
    test_dataset = SPOTS10Dataset(
        image_path=os.path.join(data_folder, "test-images-idx3-ubyte.gz"),  
        label_path=os.path.join(data_folder, "test-labels-idx1-ubyte.gz"),  
        transform=test_transform
    )

    # create DataLoader
    train_loader = DataLoader(train_subset, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    val_loader = DataLoader(val_subset, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

    
    num_classes = len(np.unique(train_dataset.labels))  # Gets the number of categories from the raw data set

    num_data = len(train_subset)  # size of train set

    return train_loader, val_loader, test_loader, num_data, num_classes